﻿namespace ApiPaises013.Controllers
{
    public class MongoDBrep
    {
    }
}